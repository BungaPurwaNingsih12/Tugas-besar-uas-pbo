/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

public class Penumpang {
    private String nama;
    private String nomorKursi;

    public Penumpang(String nama, String nomorKursi) {
        this.nama = nama;
        this.nomorKursi = nomorKursi;
    }

    public String getNama() {
        return nama;
    }

    public String getNomorKursi() {
        return nomorKursi;
    }
}
