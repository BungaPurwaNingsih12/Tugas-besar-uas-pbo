package entity;

import java.util.Date;

public class Transaksi {
    private int id;
    private String jurusan;
    private String kelas;
    private String kursi;
    private String nama;
    private int harga;
    private int jumlah;
    private int total;
    private int bayar;
    private int kembali;
    private Date tanggal;

    public Transaksi() {
    }

    // Getter dan Setter

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getJurusan() {
        return jurusan;
    }
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }
    public String getKelas() {
        return kelas;
    }
    public void setKelas(String kelas) {
        this.kelas = kelas;
    }
    public String getKursi() {
        return kursi;
    }
    public void setKursi(String kursi) {
        this.kursi = kursi;
    }
    public String getNama() {
        return nama;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    public int getHarga() {
        return harga;
    }
    public void setHarga(int harga) {
        this.harga = harga;
    }
    public int getJumlah() {
        return jumlah;
    }
    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }
    public int getTotal() {
        return total;
    }
    public void setTotal(int total) {
        this.total = total;
    }
    public int getBayar() {
        return bayar;
    }
    public void setBayar(int bayar) {
        this.bayar = bayar;
    }
    public int getKembali() {
        return kembali;
    }
    public void setKembali(int kembali) {
        this.kembali = kembali;
    }
    public Date getTanggal() {
        return tanggal;
    }
    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }
}
