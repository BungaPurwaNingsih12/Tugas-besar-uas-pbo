/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

public class Tiket {
    public static final String VIP   = "VIP";
    public static final String EKONOMI = "EKONOMI";

    private int id;
    private String jenis;    // hanya boleh "VIP" atau "EKONOMI"
    private double harga;

    public Tiket() {
    }

    public Tiket(int id, String jenis, double harga) {
        this.id = id;
        this.jenis = jenis;
        this.harga = harga;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
       this.id = id;
    }

    public String getJenis() {
       return jenis;
    }

    public void setJenis(String jenis) {
        if (!jenis.equals(VIP) && !jenis.equals(EKONOMI)) {
            throw new IllegalArgumentException("Jenis tiket harus VIP atau EKONOMI");
        }
        this.jenis = jenis;
    }

    public double getHarga() {
       return harga;
    }

    public void setHarga(double harga) {
       this.harga = harga;
    }

    @Override
    public String toString() {
        return "Tiket{" +
               "id=" + id +
               ", jenis='" + jenis + '\'' +
               ", harga=" + harga +
               '}';
    }
}
