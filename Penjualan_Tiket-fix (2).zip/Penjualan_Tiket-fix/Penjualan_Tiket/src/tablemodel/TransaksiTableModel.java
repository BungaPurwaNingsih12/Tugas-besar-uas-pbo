package tablemodel;

import entity.Transaksi;
import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.util.List;

public class TransaksiTableModel extends AbstractTableModel {
    private final List<Transaksi> list;
    private final String[] columnNames = {
        "ID", "Jurusan", "Kelas", "Harga", "Kursi", "Nama",
        "Jumlah", "Total", "Bayar", "Kembali", "Tanggal"
    };

    public TransaksiTableModel(List<Transaksi> list) {
        this.list = list;
    }

    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Transaksi t = list.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> t.getId();
            case 1 -> t.getJurusan();
            case 2 -> t.getKelas();
            case 3 -> t.getHarga();
            case 4 -> t.getKursi();
            case 5 -> t.getNama();
            case 6 -> t.getJumlah();
            case 7 -> t.getTotal();
            case 8 -> t.getBayar();
            case 9 -> t.getKembali();
            case 10 -> new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(t.getTanggal());
            default -> null;
        };
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
