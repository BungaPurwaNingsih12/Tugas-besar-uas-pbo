package tiketkereta.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;
import tiketkereta.config.Koneksi; // SUDAH BENAR
import entity.Transaksi;



public class TransaksiDAO {

    // Method simpan transaksi ke database
    public static void simpanTransaksi(
        String jurusan, String jenis, int harga,
        String nomorKursi, String namaPenumpang,
        int jumlahBeli, int totalBayar, int uangBayar, int uangKembali
    ) throws Exception {
        String sql = "INSERT INTO transaksi_tiket (jurusan, jenis_kelas, harga, nomor_kursi, nama_penumpang, jumlah_beli, total_bayar, uang_bayar, uang_kembali, waktu_transaksi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = Koneksi.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        
        ps.setString(1, jurusan);
        ps.setString(2, jenis);
        ps.setInt(3, harga);
        ps.setString(4, nomorKursi);
        ps.setString(5, namaPenumpang);
        ps.setInt(6, jumlahBeli);
        ps.setInt(7, totalBayar);
        ps.setInt(8, uangBayar);
        ps.setInt(9, uangKembali);
        ps.setTimestamp(10, new Timestamp(new Date().getTime()));  // pakai Timestamp
        
        ps.executeUpdate();
        
        ps.close();
        conn.close();
    }

    // Method ambil semua data transaksi dari database
    public static List<Transaksi> getAllTransaksi() throws Exception {
        List<Transaksi> list = new ArrayList<>();
        String sql = "SELECT * FROM transaksi_tiket";
        
        Connection conn = Koneksi.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Transaksi t = new Transaksi();
            t.setId(rs.getInt("id"));
            t.setJurusan(rs.getString("jurusan"));
            t.setKelas(rs.getString("jenis_kelas"));
            t.setHarga(rs.getInt("harga"));
            t.setKursi(rs.getString("nomor_kursi"));
            t.setNama(rs.getString("nama_penumpang"));
            t.setJumlah(rs.getInt("jumlah_beli"));
            t.setTotal(rs.getInt("total_bayar"));
            t.setBayar(rs.getInt("uang_bayar"));
            t.setKembali(rs.getInt("uang_kembali"));
            t.setTanggal(rs.getTimestamp("waktu_transaksi"));
            list.add(t);
        }
        
        rs.close();
        ps.close();
        conn.close();

        return list;
    }
}
