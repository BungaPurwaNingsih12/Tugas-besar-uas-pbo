-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Jun 2025 pada 16.08
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan_tiket`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_kereta`
--

CREATE TABLE `jadwal_kereta` (
  `id` int(11) NOT NULL,
  `jurusan_id` int(11) DEFAULT NULL,
  `nama_kereta` varchar(100) DEFAULT NULL,
  `jam_berangkat` time DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `id` int(11) NOT NULL,
  `nama_jurusan` varchar(100) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `stasiun_awal` varchar(100) DEFAULT NULL,
  `stasiun_akhir` varchar(100) DEFAULT NULL,
  `jarak_km` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_tiket`
--

CREATE TABLE `transaksi_tiket` (
  `id` int(11) NOT NULL,
  `jurusan` varchar(100) DEFAULT NULL,
  `jenis_kelas` varchar(50) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `nomor_kursi` varchar(10) DEFAULT NULL,
  `nama_penumpang` varchar(100) DEFAULT NULL,
  `jumlah_beli` int(11) DEFAULT NULL,
  `total_bayar` int(11) DEFAULT NULL,
  `uang_bayar` int(11) DEFAULT NULL,
  `uang_kembali` int(11) DEFAULT NULL,
  `waktu_transaksi` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi_tiket`
--

INSERT INTO `transaksi_tiket` (`id`, `jurusan`, `jenis_kelas`, `harga`, `nomor_kursi`, `nama_penumpang`, `jumlah_beli`, `total_bayar`, `uang_bayar`, `uang_kembali`, `waktu_transaksi`) VALUES
(1, 'Jatibarang', 'VIP', 110000, '2', 'Jojo', 4, 440000, 450000, 10000, '2025-06-04 14:26:28'),
(2, 'Jatibarang', 'VIP', 110000, '1', 'Jojo', 3, 330000, 340000, 10000, '2025-06-04 14:27:19'),
(3, 'Jatibarang', 'VIP', 110000, '2', 'Jojo', 2, 220000, 240000, 20000, '2025-06-04 14:35:31'),
(4, 'Jatibarang', 'VIP', 110000, '2', 'Jojo', 4, 440000, 450000, 10000, '2025-06-04 14:44:41'),
(5, 'Yogyakarta', 'Ekonomi', 120000, '23', 'JOJO', 2, 240000, 250000, 10000, '2025-06-04 14:53:20'),
(6, 'Yogyakarta', 'VIP', 150000, '12', 'Jojo', 3, 450000, 460000, 10000, '2025-06-04 14:56:20'),
(7, 'Jatibarang', 'VIP', 110000, '234', 'Jojo', 3, 330000, 335000, 5000, '2025-06-04 15:01:20'),
(8, 'Jatibarang', 'VIP', 110000, '12', 'eko', 3, 330000, 350000, 20000, '2025-06-04 15:06:42'),
(9, 'Jatibarang', 'VIP', 110000, '12', 'Maskani', 3, 330000, 340000, 10000, '2025-06-04 15:29:45'),
(10, 'Jatibarang', 'VIP', 110000, '172', 'Nayu', 1, 110000, 135000, 25000, '2025-06-04 18:58:33');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `jadwal_kereta`
--
ALTER TABLE `jadwal_kereta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jurusan_id` (`jurusan_id`);

--
-- Indeks untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `transaksi_tiket`
--
ALTER TABLE `transaksi_tiket`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `jadwal_kereta`
--
ALTER TABLE `jadwal_kereta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `transaksi_tiket`
--
ALTER TABLE `transaksi_tiket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `jadwal_kereta`
--
ALTER TABLE `jadwal_kereta`
  ADD CONSTRAINT `jadwal_kereta_ibfk_1` FOREIGN KEY (`jurusan_id`) REFERENCES `jurusan` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
